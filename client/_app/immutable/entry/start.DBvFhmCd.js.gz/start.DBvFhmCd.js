import{a as t}from"../chunks/entry.E24W5Nl5.js";export{t as start};
