import{a as t}from"../chunks/entry.Bf6EFcMk.js";export{t as start};
