import{a as t}from"../chunks/entry.fe2gmLlV.js";export{t as start};
