import{a as t}from"../chunks/entry.BQarArd1.js";export{t as start};
