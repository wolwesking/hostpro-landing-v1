import{a as t}from"../chunks/entry.BKSuBUAX.js";export{t as start};
